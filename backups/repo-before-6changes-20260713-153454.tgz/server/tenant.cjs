/**
 * Multi-tenant middleware & helpers
 * 
 * Strategy: Shared Database with tenant_id
 * Detection: subdomain-based (xxx.jurnal.cc.cd) or custom domain mapping
 * 
 * Flow:
 * 1. Request masuk → detect tenant dari Host header
 * 2. Cek subdomain (xxx.jurnal.cc.cd) atau custom domain (jurnal.sdit-alfatih.sch.id)
 * 3. Set req.tenant = { id, slug, nama, domain_custom, ... }
 * 4. Semua query otomatis filter by tenant_id
 */

const BASE_DOMAIN = process.env.BASE_DOMAIN || 'jurnal.cc.cd'

/**
 * Setup tenant tables in database
 */
function setupTenantTables(db) {
  db.exec(`
    CREATE TABLE IF NOT EXISTS tenants (
      id TEXT PRIMARY KEY,
      slug TEXT UNIQUE NOT NULL,
      nama TEXT NOT NULL,
      domain_custom TEXT,
      logo TEXT,
      alamat TEXT,
      telepon TEXT,
      email TEXT,
      wa_gateway_url TEXT,
      wa_gateway_key TEXT,
      plan TEXT DEFAULT 'free',
      max_siswa INTEGER DEFAULT 100,
      max_gtk INTEGER DEFAULT 20,
      aktif INTEGER DEFAULT 1,
      created_at TEXT DEFAULT (datetime('now')),
      expired_at TEXT
    );

    CREATE INDEX IF NOT EXISTS idx_tenants_slug ON tenants(slug);
    CREATE INDEX IF NOT EXISTS idx_tenants_domain ON tenants(domain_custom);
  `)

  // Ensure domain_status column exists (domain provisioning tracking)
  try {
    const cols = db.prepare("PRAGMA table_info(tenants)").all()
    if (!cols.some(c => c.name === 'domain_status')) {
      db.exec("ALTER TABLE tenants ADD COLUMN domain_status TEXT DEFAULT 'active'")
    }
  } catch {}

  // Add tenant_id to all data tables if not exists
  const tables = [
    'users', 'siswa', 'gtk', 'mapel', 'rombel', 'jadwal',
    'jurnal_mengajar', 'absensi_siswa', 'absensi_guru',
    'ekskul', 'absensi_ekskul', 'tahun_ajaran',
    'jenis_tagihan', 'tagihan', 'tabungan',
    'kalender_kbm', 'modul_ajar', 'kegiatan_khusus',
    'notif_settings', 'broadcast_log', 'settings',
    'pengajar', 'absensi_kegiatan', 'penilaian_harian'
  ]

  for (const table of tables) {
    try {
      const info = db.prepare(`PRAGMA table_info(${table})`).all()
      const hasCol = info.some(col => col.name === 'tenant_id')
      if (!hasCol) {
        db.exec(`ALTER TABLE ${table} ADD COLUMN tenant_id TEXT DEFAULT 'default'`)
        db.exec(`CREATE INDEX IF NOT EXISTS idx_${table}_tenant ON ${table}(tenant_id)`)
      }
    } catch (e) {
      // Table might not exist yet, skip
    }
  }

  // Ensure default tenant exists
  const defaultTenant = db.prepare('SELECT id FROM tenants WHERE id = ?').get('default')
  if (!defaultTenant) {
    db.prepare(`INSERT INTO tenants (id, slug, nama) VALUES (?, ?, ?)`)
      .run('default', 'demo', 'Demo Lembaga')
  }
}

/**
 * Middleware: detect tenant from request Host header
 */
function tenantMiddleware(db) {
  return (req, res, next) => {
    // Skip for static files
    if (!req.path.startsWith('/api')) return next()

    const host = (req.headers.host || '').split(':')[0].toLowerCase()

    let tenant = null

    // 1. Check if it's a subdomain of BASE_DOMAIN
    if (host.endsWith('.' + BASE_DOMAIN)) {
      const slug = host.replace('.' + BASE_DOMAIN, '')
      if (slug && slug !== 'www') {
        // Only match tenant if it does NOT have a custom domain (avoid double access)
        tenant = db.prepare('SELECT * FROM tenants WHERE slug = ? AND aktif = 1 AND (domain_custom IS NULL OR domain_custom = \'\')').get(slug)
      }
    }

    // 2. Check custom domain mapping
    if (!tenant && host !== BASE_DOMAIN && host !== 'localhost') {
      tenant = db.prepare('SELECT * FROM tenants WHERE domain_custom = ? AND aktif = 1').get(host)
    }

    // 3. Fallback to default tenant (main domain or localhost)
    if (!tenant) {
      tenant = db.prepare('SELECT * FROM tenants WHERE id = ?').get('default')
    }

    if (!tenant) {
      return res.status(404).json({ error: 'Lembaga tidak ditemukan' })
    }

    // Check expiry
    if (tenant.expired_at && new Date(tenant.expired_at) < new Date()) {
      return res.status(403).json({ error: 'Langganan lembaga sudah expired', tenant: tenant.slug })
    }

    req.tenant = tenant
    req.tenantId = tenant.id
    next()
  }
}

/**
 * Helper: wrap db query with tenant filter
 */
function tenantQuery(db, sql, tenantId, params = []) {
  return db.prepare(sql).all(...params, tenantId)
}

/**
 * Admin-only routes for tenant management (super_admin)
 */
function registerTenantRoutes(app, db, authMiddleware, uuidv4, SUPER) {
  SUPER = SUPER || authMiddleware // fallback: inline role checks below still enforce super_admin
  // List all tenants (super_admin only)
  app.get('/api/tenants', authMiddleware, (req, res) => {
    if (req.user.role !== 'super_admin') return res.status(403).json({ error: 'Forbidden' })
    const tenants = db.prepare('SELECT * FROM tenants ORDER BY created_at DESC').all()
    res.json(tenants)
  })

  // Create new tenant
  app.post('/api/tenants', authMiddleware, (req, res) => {
    if (req.user.role !== 'super_admin') return res.status(403).json({ error: 'Forbidden' })
    const { slug, nama, domain_custom, email, telepon, alamat, plan, max_siswa, max_gtk } = req.body
    if (!slug || !nama) return res.status(400).json({ error: 'slug dan nama wajib' })

    // Validate slug format
    if (!/^[a-z0-9-]+$/.test(slug)) {
      return res.status(400).json({ error: 'Slug hanya boleh huruf kecil, angka, dan dash' })
    }

    // Check duplicate
    const exists = db.prepare('SELECT id FROM tenants WHERE slug = ?').get(slug)
    if (exists) return res.status(409).json({ error: 'Slug sudah digunakan' })

    const id = uuidv4()
    db.prepare(`INSERT INTO tenants (id, slug, nama, domain_custom, email, telepon, alamat, plan, max_siswa, max_gtk) 
      VALUES (?,?,?,?,?,?,?,?,?,?)`)
      .run(id, slug, nama, domain_custom || null, email || null, telepon || null, alamat || null, plan || 'free', max_siswa || 100, max_gtk || 20)

    // Create default admin user for tenant
    const bcrypt = require('bcryptjs')
    const adminId = uuidv4()
    const adminEmail = email || `admin@${slug}.jurnal.cc.cd`
    const hashedPw = bcrypt.hashSync('admin123', 10)
    db.prepare('INSERT INTO users (id, nama, email, password, role, tenant_id) VALUES (?,?,?,?,?,?)')
      .run(adminId, `Admin ${nama}`, adminEmail, hashedPw, 'admin', id)

    // Create default settings for tenant
    db.prepare('INSERT OR IGNORE INTO settings (id, nama_lembaga, tenant_id) VALUES (?,?,?)')
      .run(uuidv4(), nama, id)

    // Create default notif_settings for tenant
    db.prepare(`INSERT OR IGNORE INTO notif_settings (id, tenant_id) VALUES (?, ?)`)
      .run('main_' + id, id)

    res.json({ id, slug, nama, admin_email: adminEmail, admin_password: 'admin123' })
  })

  // Update tenant
  app.put('/api/tenants/:id', authMiddleware, (req, res) => {
    if (req.user.role !== 'super_admin') return res.status(403).json({ error: 'Forbidden' })
    const { nama, domain_custom, plan, max_siswa, max_gtk, aktif, expired_at } = req.body
    db.prepare(`UPDATE tenants SET nama=COALESCE(?,nama), domain_custom=?, plan=COALESCE(?,plan), 
      max_siswa=COALESCE(?,max_siswa), max_gtk=COALESCE(?,max_gtk), aktif=COALESCE(?,aktif), 
      expired_at=? WHERE id=?`)
      .run(nama, domain_custom || null, plan, max_siswa, max_gtk, aktif, expired_at || null, req.params.id)
    res.json({ success: true })
  })

  // Set custom domain for tenant
  app.put('/api/tenants/:id/domain', authMiddleware, (req, res) => {
    if (req.user.role !== 'super_admin') return res.status(403).json({ error: 'Forbidden' })
    const { domain_custom } = req.body
    if (domain_custom) {
      const existing = db.prepare('SELECT id FROM tenants WHERE domain_custom = ? AND id != ?').get(domain_custom, req.params.id)
      if (existing) return res.status(400).json({ error: 'Domain sudah digunakan tenant lain' })
    }
    db.prepare('UPDATE tenants SET domain_custom = ? WHERE id = ?').run(domain_custom || null, req.params.id)
    res.json({ success: true, domain_custom })
  })

  // Delete tenant (cascade all data)
  app.delete('/api/tenants/:id', authMiddleware, (req, res) => {
    if (req.user.role !== 'super_admin') return res.status(403).json({ error: 'Forbidden' })
    if (req.params.id === 'default') return res.status(400).json({ error: 'Tidak bisa hapus tenant default' })
    const tid = req.params.id
    const tenant = db.prepare('SELECT slug, nama FROM tenants WHERE id = ?').get(tid)
    if (!tenant) return res.status(404).json({ error: 'Tenant tidak ditemukan' })
    try {
      const tables = [
        'absensi_ekskul', 'absensi_siswa', 'absensi_guru', 'absensi_kegiatan',
        'ekskul_anggota', 'tagihan', 'tabungan', 'jadwal', 'pengajar',
        'siswa', 'gtk', 'mapel', 'rombel', 'ekskul', 'jenis_tagihan',
        'tahun_ajaran', 'kalender_kbm', 'modul_ajar', 'kegiatan_khusus',
        'notif_settings', 'broadcast_log', 'penilaian_harian', 'jurnal_mengajar',
        'settings', 'users'
      ]
      for (const table of tables) {
        db.prepare(`DELETE FROM ${table} WHERE tenant_id = ?`).run(tid)
      }
      db.prepare('DELETE FROM tenants WHERE id = ?').run(tid)
      res.json({ success: true, deleted: tenant.nama })
    } catch (e) {
      console.error('Delete tenant error:', e)
      res.status(500).json({ error: 'Gagal menghapus lembaga' })
    }
  })

  // Get tenant info (for current tenant - public)
  app.get('/api/tenant/info', (req, res) => {
    const host = (req.headers.host || '').split(':')[0].toLowerCase()
    let tenant = null

    if (host.endsWith('.' + BASE_DOMAIN)) {
      const slug = host.replace('.' + BASE_DOMAIN, '')
      tenant = db.prepare('SELECT slug, nama, logo, plan FROM tenants WHERE slug = ? AND aktif = 1').get(slug)
    }
    if (!tenant && host !== BASE_DOMAIN) {
      tenant = db.prepare('SELECT slug, nama, logo, plan FROM tenants WHERE domain_custom = ? AND aktif = 1').get(host)
    }
    if (!tenant) {
      tenant = db.prepare('SELECT slug, nama, logo, plan FROM tenants WHERE id = ?').get('default')
    }

    res.json(tenant || { slug: 'default', nama: 'JURNALKU', logo: null, plan: 'free' })
  })
}

module.exports = { setupTenantTables, tenantMiddleware, tenantQuery, registerTenantRoutes, BASE_DOMAIN }
